late String userName;

Map<String, bool> userTags = {
  "Geral": true,
  "Coordenação": false,
  "Música": false,
  "Suporte": false,
  "Animação": false,
  "Cozinha": false,
  "Mídias": false,
  "Homens": false,
  "Mulheres": false,
};
